﻿using System;
using System.Collections;

namespace zad2
{
    class Massiv
    {
        static void Main()
        {
            int n = 0;
            int m = 0;
            int[,] intArray = new int[n, m];
            vvod(intArray, n, m);
            Console.ReadLine();
            stolstrok(intArray);
            Console.ReadLine();
            print(n, m);
        }


        public Massiv(int n, int m)//конструктор
        {
            int[,] intArray = new int[n, m];
        }
        static void vvod(int[,] intArray, int ns, int ms)
        {
            Console.WriteLine("Введите кол-во строк n");
            int n = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Введите кол-во столбцов m");
            int m = Convert.ToInt32(Console.ReadLine());

            int[,] intArr = new int[ns, ms];

            Console.WriteLine("Введите элементы массива");

            for (int i = 0; i < intArray.GetLength(0); i++)
            {
                Console.WriteLine("Введите элементы " + i + "-й строки:");
                for (int j = 0; j < intArray.GetLength(1); j++)
                {
                    Console.WriteLine();
                    intArray[i, j] = int.Parse(Console.ReadLine());

                }

            }

        }
        static void print(int n, int m)
        {
            int[,] intArray = new int[n, m];
            for (int i = 0; i < intArray.GetLength(0); i++)
            {
                for (int j = 0; j < intArray.GetLength(1); j++)
                {
                    Console.WriteLine("{0}\t", intArray[i, j]);
                }
            }
            Console.ReadLine();
        }


        static void stolstrok(int[,] intArray)
        {
            Console.WriteLine("Введите число, которое хотите добавить к первому элементу: ");
            int g = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(intArray[0, 0] += g);    
            Console.ReadLine();

        }
    }
}


